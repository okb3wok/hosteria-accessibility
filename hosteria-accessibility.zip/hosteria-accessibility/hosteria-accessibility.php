<?php
/*
Plugin Name: Hosteria Accessibility
Plugin URI: https://wordpress.org/plugins/hosteria-accessibility/
Description: Make your site accessible to visually impaired users: customize colors, text spacing, font sizes, and images.
Author: Alexander Dolzhenkov <okb3wok@yandex.ru>
Version: 1.2
Author URI: https://hosteria.ru/
Text Domain: hosteria-accessibility
Domain Path: /languages
License: GPLv2 or later
*/

if ( ! defined( 'ABSPATH' ) ) {
  header( 'HTTP/1.1 403 Forbidden' );
  echo 'Forbidden';
  exit;
}

/**
 * Register plugin settings with sanitization callback.
 */
function hosta11y_register_settings() {
register_setting(
  'hosta11y_settings_group',
  'hosta11y_trigger_id',
  array(
    'type'              => 'string',
    'sanitize_callback' => 'sanitize_html_class',
    'default'           => '',
  )
);
}
add_action( 'admin_init', 'hosta11y_register_settings' );

/**
 * Add options page to admin menu.
 */
function hosta11y_add_admin_menu() {
add_options_page(
  __( 'Hosteria Accessibility Settings', 'hosteria-accessibility' ),
  __( 'Hosteria Accessibility', 'hosteria-accessibility' ),
  'manage_options',
  'hosteria-accessibility',
  'hosta11y_settings_page_html'
);
}
add_action( 'admin_menu', 'hosta11y_add_admin_menu' );

/**
 * Render Settings Page
 */
function hosta11y_settings_page_html() {
  if ( ! current_user_can( 'manage_options' ) ) return;

  $trigger_id = get_option( 'hosta11y_trigger_id', '' );
  ?>
  <div class="wrap">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <form method="post" action="options.php">
      <?php settings_fields( 'hosta11y_settings_group' ); ?>
      <table class="form-table">
        <tr valign="top">
          <th scope="row"><?php esc_html_e( 'Custom Button ID', 'hosteria-accessibility' ); ?></th>
          <td>
            <input
              type="text"
              name="hosta11y_trigger_id"
              value="<?php echo esc_attr( $trigger_id ); ?>"
              class="regular-text"
              placeholder="<?php echo esc_attr( 'hosta11y-toggle-btn' ); ?>"
            />
            <p class="description">
              <?php esc_html_e( 'Leave blank to use the default floating button. Specify the element ID without the leading "#" (e.g., my-custom-button) if you want the panel to open when clicking your custom button.', 'hosteria-accessibility' ); ?>
            </p>
          </td>
        </tr>
      </table>
      <?php submit_button(); ?>
    </form>
  </div>
<?php
}

/**
 * Render accessibility UI.
 */
function hosta11y_render_ui() {
  if ( is_admin() || is_feed() ) return;

  $custom_id = trim( get_option( 'hosta11y_trigger_id', '' ) );

  ?>
  <div id="hosta11y-container">
  <?php
  if ( empty( $custom_id ) ) : ?>
    <button
      id="hosta11y-toggle-btn"
      type="button"
      class="hosta11y-toggle-btn"
      title="<?php echo esc_attr__( 'Accessibility version', 'hosteria-accessibility' ); ?>"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        class="hosta11y-toggle-icon"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        aria-hidden="true"
      >
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
      </svg>
      <svg class="hosta11y-toggle-icon hosta11y-toggle-icon__hidden" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
    </button>
  <?php endif; ?>

  <div id="hosta11y-panel" class="hosta11y-panel hosta11y-hidden">
    <div class="hosta11y-header"><?php esc_html_e( 'Color schemes and font', 'hosteria-accessibility' ); ?></div>
    <div class="hosta11y-controls-group">
      <div class="hosta11y-block">
        <span class="hosta11y-block-title"><?php esc_html_e( 'Color', 'hosteria-accessibility' ); ?></span>
        <div class="hosta11y-btn-group">
          <button id="hosta11y-btn-theme-norm" type="button" class="hosta11y-btn hosta11y-btn-theme-norm"><?php esc_html_e( 'Normal', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-theme-b" type="button" class="hosta11y-btn hosta11y-btn-theme-b"><?php esc_html_e( 'White', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-theme-ch" type="button" class="hosta11y-btn hosta11y-btn-theme-ch"><?php esc_html_e( 'Black', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-theme-g" type="button" class="hosta11y-btn hosta11y-btn-theme-g"><?php esc_html_e( 'Blue', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-theme-k" type="button" class="hosta11y-btn hosta11y-btn-theme-k"><?php esc_html_e( 'Brown', 'hosteria-accessibility' ); ?></button>
        </div>
      </div>
      <div class="hosta11y-block">
        <span class="hosta11y-block-title"><?php esc_html_e( 'Font size', 'hosteria-accessibility' ); ?></span>
        <div class="hosta11y-btn-group">
          <button id="hosta11y-btn-font-size-dec" type="button" class="hosta11y-btn hosta11y-btn-default"><?php esc_html_e( '− Smaller', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-font-size-inc" type="button" class="hosta11y-btn hosta11y-btn-default"><?php esc_html_e( '+ Larger', 'hosteria-accessibility' ); ?></button>
        </div>
      </div>
      <div class="hosta11y-block">
        <span class="hosta11y-block-title"><?php esc_html_e( 'Font', 'hosteria-accessibility' ); ?></span>
        <div class="hosta11y-btn-group">
          <button id="hosta11y-btn-font-sans" type="button" class="hosta11y-btn hosta11y-btn-sans"><?php esc_html_e( 'Sans Serif', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-font-serif" type="button" class="hosta11y-btn hosta11y-btn-serif"><?php esc_html_e( 'Serif', 'hosteria-accessibility' ); ?></button>
        </div>
      </div>
      <div class="hosta11y-block">
        <span class="hosta11y-block-title"><?php esc_html_e( 'Letter spacing', 'hosteria-accessibility' ); ?></span>
        <div class="hosta11y-btn-group">
          <button id="hosta11y-btn-kerning-dec" type="button" class="hosta11y-btn hosta11y-btn-default"><?php esc_html_e( 'Less', 'hosteria-accessibility' ); ?></button>
          <button id="hosta11y-btn-kerning-inc" type="button" class="hosta11y-btn hosta11y-btn-default hosta11y-tracking-widest"><?php esc_html_e( 'M o r e', 'hosteria-accessibility' ); ?></button>
        </div>
      </div>
      <div class="hosta11y-block">
        <span class="hosta11y-block-title"><?php esc_html_e( 'Line spacing', 'hosteria-accessibility' ); ?></span>
        <div class="hosta11y-btn-group">
          <button id="hosta11y-btn-line-height-dec" type="button" class="hosta11y-btn hosta11y-btn-default hosta11y-font-bold">///</button>
          <button id="hosta11y-btn-line-height-inc" type="button" class="hosta11y-btn hosta11y-btn-default hosta11y-font-bold">/ / /</button>
        </div>
      </div>
      <div class="hosta11y-block">
        <span class="hosta11y-block-title"><?php esc_html_e( 'Images', 'hosteria-accessibility' ); ?></span>
        <button id="hosta11y-btn-toggle-img" type="button" class="hosta11y-btn hosta11y-btn-default hosta11y-btn-img" title="<?php echo esc_attr__( 'Toggle images', 'hosteria-accessibility' ); ?>" aria-label="<?php echo esc_attr__( 'Toggle images', 'hosteria-accessibility' ); ?>">
          <span class="hosta11y-img-icon" aria-hidden="true"></span>
        </button>
      </div>
    </div>
  </div>

  </div>
  <button
    id="hosta11y-top-reset-btn"
    type="button"
    class="hosta11y-reset-top-btn"
    title="<?php echo esc_attr__( 'Reset all accessibility settings', 'hosteria-accessibility' ); ?>"
  >
    ↺ <?php esc_html_e( 'Reset View', 'hosteria-accessibility' ); ?>
  </button>
<?php
}
add_action( 'wp_footer', 'hosta11y_render_ui' );

/**
 * Register and enqueue plugin assets on frontend.
 */
function hosta11y_enqueue_assets() {
  if ( is_admin() || is_feed() ) return;

  wp_register_script(
    'hosta11y-main-script',
    plugin_dir_url( __FILE__ ) . 'assets/hosteria-accessibility.js',
    array(),
    '1.2',
    true
  );

  $custom_id = get_option( 'hosta11y_trigger_id', '' );
  wp_localize_script(
    'hosta11y-main-script',
    'hosta11yConfig',
    array(
      'triggerId' => ! empty( $custom_id ) ? sanitize_html_class( $custom_id ) : 'hosta11y-toggle-btn',
    )
  );

  wp_register_style(
    'hosta11y-main-style',
    plugin_dir_url( __FILE__ ) . 'assets/hosteria-accessibility.css',
    array(),
    '1.2'
  );

  wp_enqueue_script( 'hosta11y-main-script' );
  wp_enqueue_style( 'hosta11y-main-style' );
}
add_action( 'wp_enqueue_scripts', 'hosta11y_enqueue_assets' );